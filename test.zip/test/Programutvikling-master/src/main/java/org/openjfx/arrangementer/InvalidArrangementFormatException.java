
package org.openjfx.arrangementer;

public class InvalidArrangementFormatException extends Exception{
    InvalidArrangementFormatException(String msg) {
        super(msg);
    }
}
