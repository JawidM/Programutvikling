
package org.openjfx.billettsalg;

import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Billett{
        private SimpleStringProperty fornavn;
        private SimpleStringProperty etternavn;
        private SimpleStringProperty epost;
        private SimpleIntegerProperty telefonNummer;
        private SimpleIntegerProperty antallBilletter;
        private SimpleStringProperty arrangementInfo;
        
        
        
        
        public Billett(String fornavn, String etternavn, String epost, int telefonNummer, int antallBilletter, String arrangementInfo){
            this.fornavn = new SimpleStringProperty(fornavn);
            this.etternavn = new SimpleStringProperty(etternavn);
            this.epost = new SimpleStringProperty(epost);
            this.telefonNummer = new SimpleIntegerProperty(telefonNummer);
            this.antallBilletter = new SimpleIntegerProperty(antallBilletter);
            this.arrangementInfo = new SimpleStringProperty(arrangementInfo);
            
            
        }
        

        public String getFornavn() {
            return fornavn.get();
        }
        public void setFornavn(SimpleStringProperty fornavn){
            this.fornavn = fornavn;
        }
        

        public String getEtternavn() {
            return etternavn.get();
        }
        public void setEtternavn(SimpleStringProperty etternavn){
            this.etternavn = etternavn;
        }
        

        public String getEpost() {
            return epost.get();
        }
        public void setEpost(SimpleStringProperty epost){
            this.epost = epost;
        }
        

        public int getTelefonNummer() {
            return telefonNummer.get();
        }
        public void setTelefonNummer(SimpleIntegerProperty telefonNummer){
            this.telefonNummer = telefonNummer;
        }
        

        public int getAntallBilletter() {
            return antallBilletter.get();
        }
        public void setAntallBilletter(SimpleIntegerProperty antallBilletter){
            this.antallBilletter = antallBilletter;
        }
        

        public String getArrangementInfo() {
            return arrangementInfo.get();
        }
        public void setArrangementInfo(SimpleStringProperty arrangementInfo){
            this.arrangementInfo = arrangementInfo;
        }
        
        @Override
        public String toString() {
            return  "Kjøperen:" + fornavn +" "+ etternavn + "\n Epost adresse:" + epost +
                    ", TelefonNummer:" + telefonNummer + "\n Antall billetter kjøpt:" + 
                    antallBilletter +"\n" + "Arrangementet som er valgt:" + arrangementInfo;
        }
        
}
