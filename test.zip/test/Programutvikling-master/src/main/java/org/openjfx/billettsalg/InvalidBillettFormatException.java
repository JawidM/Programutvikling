
package org.openjfx.billettsalg;

public class InvalidBillettFormatException extends Exception {
    InvalidBillettFormatException(String msg) {
        super(msg);
    }
}
