
package org.openjfx.arrangementer;

import java.time.LocalDate;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class Arrangement{
    private SimpleStringProperty typeArrangement;
    private SimpleStringProperty sted;
    private SimpleStringProperty navn;
    private SimpleStringProperty artist;
    private LocalDate dato;
    private SimpleIntegerProperty tid;

    public Arrangement(String typeArrangement, String sted, String navn, String artist, LocalDate dato, int tid) {
        super();
        this.typeArrangement = new SimpleStringProperty(typeArrangement);
        this.sted = new SimpleStringProperty(sted);
        this.navn = new SimpleStringProperty(navn);
        this.artist = new SimpleStringProperty(artist);
        this.dato = dato;
        this.tid = new SimpleIntegerProperty(tid);
    }

    public String getTypeArrangement() {
        return typeArrangement.get();
    }

    public void setTypeArrangement(SimpleStringProperty typeArrangement) {
        this.typeArrangement = typeArrangement;
    }

    public String getSted() {
        return sted.get();
    }

    public void setSted(SimpleStringProperty sted) {
        this.sted = sted;
    }

    public String getNavn() {
        return navn.get();
    }

    public void setNavn(SimpleStringProperty navn) {
        this.navn = navn;
    }

    public String getArtist() {
        return artist.get();
    }

    public void setArtist(SimpleStringProperty artist) {
        this.artist = artist;
    }

    public LocalDate getDato() {
        return dato;
    }

    public void setDato(LocalDate dato) {
        this.dato = dato;
    }

    public int getTid() {
        return tid.get();
    }

    public void setTid(SimpleIntegerProperty tid) {
        this.tid = tid;
    }

    @Override
    public String toString() {
        return "Type Arrangement:" + typeArrangement + ", Sted:" + sted + ", Navn:" + navn + 
                ", Artist/Leder:" + artist + ", Dato:" + dato + ", Klokka:" + tid +"\n";
    }
    
    
}  
