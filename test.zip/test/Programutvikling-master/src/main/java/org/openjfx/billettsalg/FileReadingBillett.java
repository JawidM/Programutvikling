
package org.openjfx.billettsalg;

//import java.io.IOException;
//import java.util.ArrayList;
//import java.util.List;
//import org.openjfx.arrangementer.Arrangement;
//import org.openjfx.arrangementer.ArrangementReader;
//import org.openjfx.arrangementer.InvalidArrangementFormatException;


public class FileReadingBillett {
//    public static void main(String[] args){
//        List<Billett> arrayListBillett = new ArrayList<>();
//
//         try {
//            arrayListBillett = BillettReader.readBilletter("/Users/jawidmohammadi/Documents/GitHub/Programutvikling/src/main/resources/org/openjfx/billettsalg.csv");
//        } catch (IOException e) {
//            System.err.println("Could not read the requested file. Cause: " + e.getCause());
//        } catch (InvalidBillettFormatException e) {
//            System.err.println("The data is not formatted correctly. Message: " + e.getMessage());
//        }
//
//        if(arrayListBillett == null) { // some error has occurred
//            System.exit(1);
//        }
//        System.out.println(arrayListBillett);
//    }
}
