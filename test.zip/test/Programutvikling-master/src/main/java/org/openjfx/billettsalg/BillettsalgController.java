
package org.openjfx.billettsalg;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.stage.Window;
import org.openjfx.arrangementer.AlertHelper;
import org.openjfx.arrangementer.Arrangement;
import org.openjfx.arrangementer.ArrangementReader;
import org.openjfx.arrangementer.InvalidArrangementFormatException;


public class BillettsalgController implements Initializable {
    
    @FXML
    private Spinner<Integer> spiAntallBilletter;

    @FXML
    private TextField txtFornavn;

    @FXML
    private TextField txtEtternavn;

    @FXML
    private TextField txtEpost;

    @FXML
    private TextField txtTelefonNummer;

    @FXML
    private TableView<Arrangement> listView;

    @FXML
    private Button btnAvbrytt;

    @FXML
    private TableView<Billett> listViewBillett;

    @FXML
    private TableColumn<Billett, String> tableFornavn;

    @FXML
    private TableColumn<Billett, String> tableEtternavn;

    @FXML
    private TableColumn<Billett, String> tableEpost;

    @FXML
    private TableColumn<Billett, Integer> tableTlfnr;

    @FXML
    private TableColumn<Billett, Integer> tableAntallBillett;

    @FXML
    private TableColumn<Billett, String> tableArrangement;
    
    
    

    static ObservableList<Arrangement> arrayListArrangement = FXCollections.observableArrayList();
    
    
    Billett en;
    static ObservableList<Billett> arrayListBillett = FXCollections.observableArrayList();
    
    

    @Override
    
    public void initialize(URL url, ResourceBundle rb) {
        
        //Henter data fra arrangement.csv filen
        try {
            arrayListArrangement = ArrangementReader.readArrangementer("/Users/jawidmohammadi/Documents/GitHub/Programutvikling/src/main/resources/org/openjfx/arrangementer.csv");
        } catch (IOException e) {
            System.err.println("Could not read the requested file. Cause: " + e.getCause());
        } catch (InvalidArrangementFormatException e) {
            System.err.println("The data is not formatted correctly. Message: " + e.getMessage());
        }
        listView.getItems().addAll(arrayListArrangement);
        
        //henter data fra billettsalg.csv filen
        try {
            arrayListBillett = (ObservableList<Billett>) BillettReader.readBilletter("/Users/jawidmohammadi/Documents/GitHub/Programutvikling/src/main/resources/org/openjfx/billettsalg.csv");
        } catch (IOException e) {
            System.err.println("Could not read the requested file. Cause: " + e.getCause());
        } catch (InvalidBillettFormatException e) {
            System.err.println("The data is not formatted correctly. Message: " + e.getMessage());
        }
        listViewBillett.getItems().addAll(arrayListBillett);
        
        SpinnerValueFactory<Integer> antallBilletterValueFactory = new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 50, 1);
        spiAntallBilletter.setValueFactory(antallBilletterValueFactory);
        spiAntallBilletter.setEditable(true);
        
        tableFornavn.setCellValueFactory(new PropertyValueFactory<Billett, String>("fornavn"));
        tableEtternavn.setCellValueFactory(new PropertyValueFactory<Billett, String>("etternavn"));
        tableEpost.setCellValueFactory(new PropertyValueFactory<Billett, String>("epost"));
        tableTlfnr.setCellValueFactory(new PropertyValueFactory<Billett, Integer>("telefonNummer"));
        tableAntallBillett.setCellValueFactory(new PropertyValueFactory<Billett, Integer>("antallBilletter"));
        tableArrangement.setCellValueFactory(new PropertyValueFactory<Billett, String>("arrangementInfo"));
        listViewBillett.setItems(arrayListBillett);
        
        
    }  
    
    @FXML
    private void registrerBillett(ActionEvent event) throws IOException {
    
        if (validateFornavn() && validateEtternavn() && validateEpost() && validateTelefonNummer()) {
            
            
            
            
            
            
            String cFornavn = txtFornavn.getText();
            String cEtternavn = txtEtternavn.getText();
            String cEpost = txtEpost.getText();
            int cTlf = Integer.parseInt(txtTelefonNummer.getText());
            int cAntBillett = spiAntallBilletter.getValue();
            String cArrangement = listView.getSelectionModel().getSelectedItems().toString();

            
            en = new Billett(cFornavn, cEtternavn, cEpost, cTlf, cAntBillett, cArrangement);
            String sb = getCsvLine(en);
            
           
            File file = new File("C:/Users/Eier/Documents/GitHub/Programutvikling/src/main/java/org/openjfx/billettsalg.csv");
            BufferedWriter w = new BufferedWriter(new FileWriter(file, true));
            w.append(sb.toString());
            w.close();

            listViewBillett.getItems().add(en);
        } 
            
            
            
           
        
        //validering av registrering skjema
//        Window owner = txtFornavn.getScene().getWindow();   
//        if(txtFornavn.getText().isEmpty()){
//            AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Error!", "Vennligst tast inn fornavn");
//            return;
//        }
//
//        else if(txtEtternavn.getText().isEmpty()){
//            AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Error!", "Vennligst tast inn etternavn");
//            return;
//        }
//
//        else if((txtEpost.getText()).isEmpty()){
//            AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Error!", "Vennligst tast inn epost");
//            return;
//        }
//        
//        else if((txtTelefonNummer.getText()).isEmpty()){
//            AlertHelper.showAlert(Alert.AlertType.ERROR, owner, "Error!", "Vennligst tast inn telefonnummer");
//            return;
//        }
        
        //LocalDate dato = dpDate.getValue();
        //DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-mm-yyyy");
         
    }  
    
    @FXML
    private void avbrytt(ActionEvent event){
        Stage stage = (Stage) btnAvbrytt.getScene().getWindow();
        stage.close();
    }
    
    
            
    private String getCsvLine(Billett nyBillett){
        StringBuilder sb = new StringBuilder();
        sb.append(nyBillett.getFornavn()+ ",");
        sb.append(nyBillett.getEtternavn()+ ",");
        sb.append(nyBillett.getEpost()+ ",");
        sb.append(nyBillett.getTelefonNummer()+ ",");
        sb.append(nyBillett.getAntallBilletter()+ ",");
        sb.append(nyBillett.getArrangementInfo() + ",");
        sb.append(System.lineSeparator()); //new line
        return sb.toString();
    }
    
    private boolean validateFornavn(){
        Pattern p = Pattern.compile("[A-ZÆØÅa-zæøå\\s]+");
        Matcher m = p.matcher(txtFornavn.getText());
        if(m.find() && m.group().equals(txtFornavn.getText())){
            return true;
        }else{
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("Validate fornavn");
                alert.setHeaderText(null);
                alert.setContentText("Vennlist tast inn gyldig fornavn");
                alert.showAndWait();
            
            return false;            
        }
    }
    
    private boolean validateEtternavn(){
        Pattern p = Pattern.compile("[A-ZÆØÅa-zæøå\\s]+");
        Matcher m = p.matcher(txtEtternavn.getText());
        if(m.find() && m.group().equals(txtEtternavn.getText())){
            return true;
        }else{
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("Validate etternavn");
                alert.setHeaderText(null);
                alert.setContentText("Vennlist tast inn gyldig etternavn");
                alert.showAndWait();
            
            return false;            
        }
    }
    
    private boolean validateEpost(){
        Pattern p  = Pattern.compile("[a-zA-Z0-9][a-zA-Z0-9._]*@[a-zA-Z0-9]+([.][a-zA-Z]+)+");
        Matcher m = p.matcher(txtEpost.getText());
        if (m.find() && m.group().equals(txtEpost.getText())){
            return true;
        }
        else{
            Alert alert = new Alert(AlertType.WARNING);
            alert.setTitle("Validate epost");
            alert.setHeaderText(null);
            alert.setContentText("Vennlist tast inn gyldig epost");
            alert.showAndWait();
            return false;
        }
    }
    
    private boolean validateTelefonNummer(){
        Pattern p = Pattern.compile("[0-9]{8}");
        Matcher m = p.matcher(txtTelefonNummer.getText());
        if(m.find() && m.group().equals(txtTelefonNummer.getText())){
            return true;
        }else{
                Alert alert = new Alert(AlertType.WARNING);
                alert.setTitle("Validate telefonnummer");
                alert.setHeaderText(null);
                alert.setContentText("Vennlist tast inn gyldig telefonnummer");
                alert.showAndWait();
            
            return false;            
        }
    }
    
    
}






